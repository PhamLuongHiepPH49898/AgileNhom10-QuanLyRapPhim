package com.example.nhom10agile.Repository;

import com.example.nhom10agile.Entity.RapPhim;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RapPhimRepo extends JpaRepository<RapPhim, Long> {
}
