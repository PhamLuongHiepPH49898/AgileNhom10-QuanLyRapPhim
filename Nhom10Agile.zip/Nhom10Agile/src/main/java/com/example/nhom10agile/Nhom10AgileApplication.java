package com.example.nhom10agile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nhom10AgileApplication {

    public static void main(String[] args) {
        SpringApplication.run(Nhom10AgileApplication.class, args);
        System.out.println("Toi dang chay (^_^)");
    }

}
