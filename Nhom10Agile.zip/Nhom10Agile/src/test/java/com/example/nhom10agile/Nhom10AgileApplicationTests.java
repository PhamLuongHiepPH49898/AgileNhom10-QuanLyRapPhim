package com.example.nhom10agile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nhom10AgileApplicationTests {

    @Test
    void contextLoads() {
    }

}
